package com.example.keuanganku;

import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;

import androidx.annotation.OptIn;
import androidx.appcompat.app.AppCompatActivity;
import androidx.compose.ui.ExperimentalComposeUiApi;
import androidx.compose.ui.input.pointer.HistoricalChange;

public class MainActivity extends AppCompatActivity {

    Button btnAddTransaction, btnViewHistory;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        btnAddTransaction = findViewById(R.id.btn_add_transaction);
        btnViewHistory = findViewById(R.id.btn_history);

        btnAddTransaction.setOnClickListener(v -> {
            Intent intent = new Intent(MainActivity.this, AddTransactionActivity.class);
            startActivity(intent);
        });

        btnViewHistory.setOnClickListener(new View.OnClickListener() {
            @OptIn(markerClass = ExperimentalComposeUiApi.class)
            @Override
            public void onClick(View v) {
                Intent intent = new Intent(MainActivity.this, HistoricalChange.class);
                startActivity(intent);
            }
        });
    }
}
