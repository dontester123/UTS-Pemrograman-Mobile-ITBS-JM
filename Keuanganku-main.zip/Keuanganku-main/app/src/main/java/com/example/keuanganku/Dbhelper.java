package com.example.keuanganku;

import android.content.ContentValues;
import android.content.Context;
import android.database.sqlite.SQLiteDatabase;
import android.database.sqlite.SQLiteOpenHelper;

public class Dbhelper extends SQLiteOpenHelper {
    public android.content.ContentValues ContentValues;

    public Dbhelper(Context context) {
        super(context, "Keuangan.db", null, 1);
    }

    public void onCreate(SQLiteDatabase db) {
        db.execSQL("CREATE TABLE transaksi(id INTEGER PRIMARY KEY AUTOINCREMENT, amount INTEGER, description TEXT, category TEXT, type TEXT, date TEXT)");
    }

    @Override
    public void onUpgrade(SQLiteDatabase db, int oldVersion, int newVersion) {

    }

    public boolean insertData(int amount, String desc, String category, String type, String date) {
        SQLiteDatabase db = this.getWritableDatabase();
        ContentValues contentValues = new ContentValues();
        contentValues.put("amount", amount);
        contentValues.put("description", desc);
        contentValues.put("category", category);
        contentValues.put("type", type);
        contentValues.put("date", date);
        long result = db.insert("transaksi", null, ContentValues);
        return result != -1;
    }
}
