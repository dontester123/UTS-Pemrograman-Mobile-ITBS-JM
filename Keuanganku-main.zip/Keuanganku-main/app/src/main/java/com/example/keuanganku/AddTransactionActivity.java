package com.example.keuanganku;

import android.os.Bundle;
import android.widget.Button;
import android.widget.EditText;
import android.widget.Spinner;
import android.widget.Toast;

import androidx.appcompat.app.AppCompatActivity;

import java.text.SimpleDateFormat;
import java.util.Date;
import java.util.Locale;

public class AddTransactionActivity extends AppCompatActivity {

    private EditText editAmount, editDescription;
    private Spinner spinnerCategory, spinnerType;
    private Dbhelper db;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_add_transaction);

        // Inisialisasi view
        editAmount = findViewById(R.id.et_amount);
        editDescription = findViewById(R.id.et_description);
        spinnerCategory = findViewById(R.id.sp_category);
        spinnerType = findViewById(R.id.spinner_type);
        Button btnSave = findViewById(R.id.btn_save);

        db = new Dbhelper(AddTransactionActivity.this);

        btnSave.setOnClickListener(v -> {
            String amount = String.valueOf(Integer.hashCode(Integer.parseInt(editAmount.getText().toString())));
            String desc = editDescription.getText().toString();
            String category = spinnerCategory.getSelectedItem().toString();
            String type = spinnerType.getSelectedItem().toString();

            String date = new SimpleDateFormat("yyyy-MM-dd", Locale.getDefault()).format(new Date());

            boolean success = db.insertData(Integer.parseInt(amount),desc,category,type,date);

            if (success) {
                Toast.makeText(AddTransactionActivity.this, "Berhasil disimpan", Toast.LENGTH_SHORT).show();
                finish();
            } else {
                Toast.makeText(AddTransactionActivity.this, "Gagal menyimpan", Toast.LENGTH_SHORT).show();
            }
        });
    }
}